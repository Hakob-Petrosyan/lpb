<?php
require_once (dirname(__DIR__) . '/blocktablevalue.class.php');
class blockTableValue_mysql extends blockTableValue {}