<?php
class blockTable extends xPDOSimpleObject {}