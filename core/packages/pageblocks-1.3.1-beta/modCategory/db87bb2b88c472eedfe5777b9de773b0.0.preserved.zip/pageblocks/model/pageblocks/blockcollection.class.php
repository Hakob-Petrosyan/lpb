<?php
class blockCollection extends xPDOSimpleObject {}