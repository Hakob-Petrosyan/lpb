<?php
class blockFieldGroup extends xPDOSimpleObject {}