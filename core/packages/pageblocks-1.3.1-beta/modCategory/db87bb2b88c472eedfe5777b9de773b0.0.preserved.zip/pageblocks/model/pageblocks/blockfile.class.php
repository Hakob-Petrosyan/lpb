<?php
class blockFile extends xPDOSimpleObject {}