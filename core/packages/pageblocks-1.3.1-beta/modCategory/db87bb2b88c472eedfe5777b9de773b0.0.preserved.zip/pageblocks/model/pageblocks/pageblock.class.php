<?php
class pageBlock extends xPDOSimpleObject {}