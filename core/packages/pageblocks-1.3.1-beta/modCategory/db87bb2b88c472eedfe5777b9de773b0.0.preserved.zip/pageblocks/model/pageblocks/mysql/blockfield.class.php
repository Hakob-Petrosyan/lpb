<?php
require_once (dirname(__DIR__) . '/blockfield.class.php');
class blockField_mysql extends blockField {}