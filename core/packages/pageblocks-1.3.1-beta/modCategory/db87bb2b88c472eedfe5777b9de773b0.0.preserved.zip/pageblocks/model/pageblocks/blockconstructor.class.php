<?php
class blockConstructor extends xPDOSimpleObject {}