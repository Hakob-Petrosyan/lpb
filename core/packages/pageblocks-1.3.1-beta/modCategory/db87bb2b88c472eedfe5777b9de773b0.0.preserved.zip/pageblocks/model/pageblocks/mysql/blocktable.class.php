<?php
require_once (dirname(__DIR__) . '/blocktable.class.php');
class blockTable_mysql extends blockTable {}