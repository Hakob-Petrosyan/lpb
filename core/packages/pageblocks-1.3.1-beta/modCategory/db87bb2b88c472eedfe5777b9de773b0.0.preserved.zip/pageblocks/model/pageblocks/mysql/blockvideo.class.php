<?php
require_once (dirname(__DIR__) . '/blockvideo.class.php');
class blockVideo_mysql extends blockVideo {}