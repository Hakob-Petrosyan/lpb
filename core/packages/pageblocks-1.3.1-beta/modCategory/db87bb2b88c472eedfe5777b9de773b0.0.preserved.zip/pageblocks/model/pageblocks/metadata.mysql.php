<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'pageBlock',
    1 => 'blockConstructor',
    2 => 'blockTable',
    3 => 'blockCollection',
    4 => 'blockField',
    5 => 'blockFieldGroup',
    6 => 'pbTableColumn',
    7 => 'blockTableValue',
    8 => 'blockFile',
    9 => 'blockVideo',
    10 => 'pbResourceColumn',
    11 => 'pbVersion',
    12 => 'pbVersionTableValue',
    13 => 'pbVersionFile',
    14 => 'pbVersionVideo',
  ),
);