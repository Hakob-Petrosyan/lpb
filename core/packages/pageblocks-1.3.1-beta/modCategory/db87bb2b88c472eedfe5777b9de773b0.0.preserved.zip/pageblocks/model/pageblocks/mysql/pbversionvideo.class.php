<?php
require_once (dirname(__DIR__) . '/pbversionvideo.class.php');
class pbVersionVideo_mysql extends pbVersionVideo {}