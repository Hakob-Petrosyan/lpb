<?php
class pbResourceColumn extends xPDOSimpleObject {}