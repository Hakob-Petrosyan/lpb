<?php
class pageBlockFile extends xPDOSimpleObject {}