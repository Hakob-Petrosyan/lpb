<?php
class pbTableColumn extends xPDOSimpleObject {}