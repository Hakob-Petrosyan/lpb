<?php
require_once (dirname(__DIR__) . '/pbtablecolumn.class.php');
class pbTableColumn_mysql extends pbTableColumn {}