<?php
require_once (dirname(__DIR__) . '/pbversiontablevalue.class.php');
class pbVersionTableValue_mysql extends pbVersionTableValue {}