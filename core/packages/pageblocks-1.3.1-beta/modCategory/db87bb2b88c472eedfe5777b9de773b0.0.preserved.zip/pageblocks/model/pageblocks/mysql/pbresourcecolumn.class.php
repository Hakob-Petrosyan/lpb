<?php
require_once (dirname(__DIR__) . '/pbresourcecolumn.class.php');
class pbResourceColumn_mysql extends pbResourceColumn {}