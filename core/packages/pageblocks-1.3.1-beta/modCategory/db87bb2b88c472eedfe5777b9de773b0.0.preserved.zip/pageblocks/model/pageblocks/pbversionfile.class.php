<?php
class pbVersionFile extends xPDOSimpleObject {}