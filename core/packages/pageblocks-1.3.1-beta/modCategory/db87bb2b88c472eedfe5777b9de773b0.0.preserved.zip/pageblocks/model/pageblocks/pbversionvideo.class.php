<?php
class pbVersionVideo extends xPDOSimpleObject {}