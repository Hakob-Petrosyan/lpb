<?php
require_once (dirname(__DIR__) . '/blockfieldgroup.class.php');
class blockFieldGroup_mysql extends blockFieldGroup {}