<?php
require_once (dirname(__DIR__) . '/pbversion.class.php');
class pbVersion_mysql extends pbVersion {}