<?php
class pbResourceField extends xPDOSimpleObject {}