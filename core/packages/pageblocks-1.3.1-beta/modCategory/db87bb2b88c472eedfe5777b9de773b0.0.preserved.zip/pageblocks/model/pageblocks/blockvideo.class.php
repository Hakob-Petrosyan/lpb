<?php
class blockVideo extends xPDOSimpleObject {}