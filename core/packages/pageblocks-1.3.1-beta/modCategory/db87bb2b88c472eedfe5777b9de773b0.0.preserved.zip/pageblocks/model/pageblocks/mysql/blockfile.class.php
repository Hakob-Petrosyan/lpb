<?php
require_once (dirname(__DIR__) . '/blockfile.class.php');
class blockFile_mysql extends blockFile {}