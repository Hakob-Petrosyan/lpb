<?php

$_lang['ajaxform'] = 'AjaxForm';

$_lang['af_message_close_all'] = 'Закрити все';
$_lang['af_submit'] = 'Відправити';
$_lang['af_reset'] = 'Очистити';

$_lang['af_label_name'] = "Ім'я";
$_lang['af_label_email'] = 'E-mail';
$_lang['af_label_message'] = 'Повідомлення';

$_lang['af_err_action_ns'] = 'Не вказано ключ форми (action).';
$_lang['af_err_action_nf'] = 'Не можу знайти вказаного ключа форми (action).';
$_lang['af_err_chunk_ns'] = 'Не вказано чанк для зворотньої форми.';
$_lang['af_err_chunk_nf'] = 'Не можу знайти вказаного чанку "[[+name]]" з формою.';
$_lang['af_err_snippet_ns'] = 'Не вказано сніппету для зворотньої форми.';
$_lang['af_err_snippet_nf'] = 'Не можу знайти вказаного сніппету "[[+name]]" для обробки форми.';
$_lang['af_err_has_errors'] = 'Форма містить помилки';
$_lang['af_success_submit'] = 'Форма успішно відправлена';
