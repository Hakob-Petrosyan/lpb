<?php

$_lang['ajaxform_prop_form'] = 'Чанк з формою для відправлення.';
$_lang['ajaxform_prop_snippet'] = 'Сніппет, який буде обробляти вказану форму.';
$_lang['ajaxform_prop_frontend_css'] = 'Файл з css стилями для підключення на фронтенді.';
$_lang['ajaxform_prop_frontend_js'] = 'Файл с javascript для підключення на фронтенді.';
$_lang['ajaxform_prop_actionUrl'] = 'Конектор для обробки ajax запитів.';
$_lang['ajaxform_prop_formSelector'] = "Им'я CSS класу, якого буде використано як jQuery селектор для ініціалізації форми. Усталене значення 'ajax_form'.";
$_lang['ajaxform_prop_objectName'] = "Им'я об'єкту для ініціалізації у підключаємому javascript. Усталене значення 'AjaxForm'.";
$_lang['ajaxform_prop_clearFieldsOnSuccess'] = 'Якщо значення true, очистить поля при успішному надсиланні форми без редиректу.';
