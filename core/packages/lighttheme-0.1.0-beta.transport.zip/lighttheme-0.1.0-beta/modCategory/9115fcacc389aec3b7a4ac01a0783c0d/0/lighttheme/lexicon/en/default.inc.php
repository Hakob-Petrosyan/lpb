
	<?php
	/**
	 * Default English Lexicon Entries for Socialstream
	 *
	 * @package    lighttheme
	 * @subpackage lexicon
	 */
	$_lang['lighttheme']              = 'LightTheme';
	