<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Іконкі';
$_lang['iconstv.desc'] = 'Выбярыце падтрымку іконак';
$_lang['iconstv.noSearch'] = 'Адключыць пошук';
$_lang['iconstv.preview'] = 'Папярэдні прагляд';