<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Іконки';
$_lang['iconstv.desc'] = 'Виберіть підтримку піктограм';
$_lang['iconstv.noSearch'] = 'Вимкнути панель пошуку';
$_lang['iconstv.preview'] = 'Попередній перегляд';