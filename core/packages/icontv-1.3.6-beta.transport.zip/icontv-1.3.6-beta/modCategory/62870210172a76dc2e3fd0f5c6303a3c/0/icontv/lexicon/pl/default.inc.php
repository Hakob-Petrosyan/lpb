<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Ikonka';
$_lang['iconstv.desc'] = 'Wybierz wsparcie dla ikon';
$_lang['iconstv.noSearch'] = 'Wyłącz wyszukiwanie';
$_lang['iconstv.preview'] = 'Podgląd';