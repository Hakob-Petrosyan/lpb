<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Иконки';
$_lang['iconstv.desc'] = 'Выберите поддержку иконок';
$_lang['iconstv.noSearch'] = 'Отключить поиск';
$_lang['iconstv.preview'] = 'Предварительный просмотр';