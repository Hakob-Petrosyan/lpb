<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Ícones';
$_lang['iconstv.desc'] = 'Selecione ícones de suporte';
$_lang['iconstv.noSearch'] = 'Disable search';
$_lang['iconstv.preview'] = 'Pré visualização';