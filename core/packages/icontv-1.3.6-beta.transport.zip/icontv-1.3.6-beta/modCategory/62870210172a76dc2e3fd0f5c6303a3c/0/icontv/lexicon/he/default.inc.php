<?php
/**
 * Default Lexicon Entries for IconTV
 *
 * @package icontv
 * @subpackage lexicon
 */

$_lang['icons'] = 'Icons';
$_lang['iconstv.desc'] = 'Select icons support';
$_lang['iconstv.noSearch'] = 'Disable search';
$_lang['iconstv.preview'] = 'Preview';