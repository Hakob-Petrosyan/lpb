--------------------
SweetAlert2
--------------------
Author: Aleksandr Huz <Superboshnik@gmail.com>
--------------------
