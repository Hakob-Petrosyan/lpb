/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'cs', {
	alt: 'Alternativní text',
	btnUpload: 'Odeslat na server',
	captioned: 'Obrázek s popisem',
	captionPlaceholder: 'Popis',
	infoTab: 'Informace o obrázku',
	lockRatio: 'Zámek',
	menu: 'Vlastnosti obrázku',
	pathName: 'Obrázek',
	pathNameCaption: 'Popis',
	resetSize: 'Původní velikost',
	resizer: 'Klepněte a táhněte pro změnu velikosti',
	title: 'Vlastnosti obrázku',
	uploadTab: 'Odeslat',
	urlMissing: 'Zadané URL zdroje obrázku nebylo nalezeno.',
	altMissing: 'Alternativní text chybí.'
} );
