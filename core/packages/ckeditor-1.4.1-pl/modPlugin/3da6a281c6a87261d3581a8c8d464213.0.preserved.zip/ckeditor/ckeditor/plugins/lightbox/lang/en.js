﻿
CKEDITOR.plugins.setLang( 'lightbox', 'en', {
	label: 'Lightbox',
	url: 'Image to display in Lightbox',
    preview: 'Preview',
    title: 'Image title',
    gallery: 'Gallery name'
} );
