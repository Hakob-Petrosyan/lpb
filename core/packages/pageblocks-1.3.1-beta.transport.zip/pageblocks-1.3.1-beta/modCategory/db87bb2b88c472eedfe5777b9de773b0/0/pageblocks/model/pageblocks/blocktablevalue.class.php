<?php
class blockTableValue extends xPDOSimpleObject {}