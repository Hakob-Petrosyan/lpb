<?php
class blockField extends xPDOSimpleObject {}