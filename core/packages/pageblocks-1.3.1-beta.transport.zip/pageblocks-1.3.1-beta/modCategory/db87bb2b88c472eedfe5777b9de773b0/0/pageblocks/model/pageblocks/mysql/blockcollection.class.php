<?php
require_once (dirname(__DIR__) . '/blockcollection.class.php');
class blockCollection_mysql extends blockCollection {}