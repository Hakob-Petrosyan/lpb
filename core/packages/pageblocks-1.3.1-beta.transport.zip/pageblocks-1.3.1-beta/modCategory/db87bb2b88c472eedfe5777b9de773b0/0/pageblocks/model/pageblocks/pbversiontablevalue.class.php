<?php
class pbVersionTableValue extends xPDOSimpleObject {}