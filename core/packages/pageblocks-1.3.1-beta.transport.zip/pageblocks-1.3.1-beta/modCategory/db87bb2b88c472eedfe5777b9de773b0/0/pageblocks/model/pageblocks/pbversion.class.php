<?php
class pbVersion extends xPDOSimpleObject {}