<?php
class blockTab extends xPDOSimpleObject {}