<?php
require_once (dirname(__DIR__) . '/pageblock.class.php');
class pageBlock_mysql extends pageBlock {}