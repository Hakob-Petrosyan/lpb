<?php
class pbGridColumn extends xPDOSimpleObject {}