<?php
require_once (dirname(__DIR__) . '/blockconstructor.class.php');
class blockConstructor_mysql extends blockConstructor {}