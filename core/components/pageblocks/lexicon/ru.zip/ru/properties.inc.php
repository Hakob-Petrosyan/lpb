<?php

$_lang['pageblocks_prop_id'] = 'Id блока.';
$_lang['pageblocks_prop_object_id'] = 'Id привязанного ресурса.';
$_lang['pageblocks_prop_rid'] = 'Id ресурса.';
$_lang['pageblocks_prop_cid'] = 'Id конструктора блока.';
$_lang['pageblocks_prop_collection'] = 'Id коллекции.';
$_lang['pageblocks_prop_context'] = 'Контекст.';
$_lang['pageblocks_prop_cultureKey'] = 'Язык.';
$_lang['pageblocks_prop_up'] = 'Параметр, который позволяет искать условие у родителей.';
$_lang['pageblocks_prop_fastMode'] = 'Быстрый режим обработки чанков. Все необработанные теги (условия, сниппеты и т.п.) будут вырезаны.';
$_lang['pageblocks_prop_where'] = 'Массив дополнительных параметров выборки, закодированный в JSON.';
$_lang['pageblocks_prop_showLog'] = 'Показывать дополнительную информацию о работе сниппета.';
$_lang['pageblocks_prop_return'] = 'Формат вывода данных.';